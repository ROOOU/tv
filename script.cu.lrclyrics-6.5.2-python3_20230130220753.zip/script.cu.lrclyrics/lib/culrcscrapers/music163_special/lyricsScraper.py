#-*- coding: UTF-8 -*-
'''
Scraper for plugin.audio.music163

osdlyrics
'''

import os
import requests
import re
import random
import difflib
from lib.utils import *

__title__ = "Music163 by ID"
__priority__ = '0'
__lrc__ = True

headers = {}
headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'


class LyricsFetcher:
    def __init__(self, *args, **kwargs):
        self.DEBUG = kwargs['debug']
        self.settings = kwargs['settings']
        self.SEARCH_URL = 'http://music.163.com/api/search/get'
        self.LYRIC_URL = 'http://music.163.com/api/song/lyric'

    def get_lyrics(self, song):
        log("%s: searching lyrics for %s - %s" % (__title__, song.artist, song.title), debug=self.DEBUG)
        lyrics = Lyrics(settings=self.settings)
        lyrics.song = song
        lyrics.source = __title__
        lyrics.lrc = __lrc__
        artist = song.artist.replace(' ', '+')
        title = song.title.replace(' ', '+')
        links = []
        if not song.dbid:
            return None
        links.append((song.artist + ' - ' + song.title, self.LYRIC_URL + '?id=' + str(song.dbid) + '&lv=-1&rv=-1&tv=-1', song.artist, song.title))
        lyrics.list = links
        for link in links:
            lyr = self.get_lyrics_from_list(link)
            if lyr and lyr.startswith('['):
                lyrics.lyrics = lyr
                return lyrics
        return None

    def remove_blank_line(self, lrc):
        tag = re.compile('\[(\d+):(\d\d)')
        newlrc = ''
        lrc.replace('\r\n', '\n')
        lines = lrc.split('\n')
        for line in lines:
            if tag.match(line):
                text = line.split(']')[1].strip()
                if not text or (text[0] == '[' and text[-1] == ']'):
                    continue
            newlrc += line + '\n'
        return newlrc

    def get_lyrics_from_list(self, link):
        title,url,artist,song = link
        try:
            log('%s: search url: %s' % (__title__, url), debug=self.DEBUG)
            response = requests.get(url, headers=headers, timeout=10)
            result = response.json()
        except:
            return None
        lyrics = ''

        if 'lrc' in result and result['lrc']['lyric']:
            lyrics += self.remove_blank_line(result['lrc']['lyric'])
        if self.settings['show_translated_lyric']:
            if 'tlyric' in result and result['tlyric']['lyric']:
                lyrics += self.remove_blank_line(result['tlyric']['lyric'])
        if self.settings['show_roman_lyric']:
            if 'romalrc' in result and result['romalrc']['lyric']:
                lyrics += self.remove_blank_line(result['romalrc']['lyric'])
        return lyrics
